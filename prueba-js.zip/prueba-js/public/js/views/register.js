import { getUsers, createUser } from '../api/api.js';

const Register = () => {
return `
    <section class="section">
    <div class="container is-flex is-justify-content-center">
        <div class="box" style="max-width: 400px; width: 100%; background-color:rgb(255, 255, 255); border-radius: 12px;">
        <h1 class="title has-text-centered">Register</h1>

        <form id="register-form">
            <div class="field">
            <label class="label has-text-dark" for="username">Username</label>
            <div class="control">
                <input class="input" type="text" id="username" required>
            </div>
            </div>

            <div class="field">
            <label class="label has-text-dark" for="email">Email</label>
            <div class="control">
                <input class="input" type="email" id="email" required>
            </div>
            </div>

            <div class="field">
            <label class="label has-text-dark">Password</label>
            <div class="control">
                <input class="input" type="password" id="password" required>
            </div>
            </div>

            <div class="field mt-4">
            <div class="control">
                <button id="RegisterBtn" style=" font-weight: 600" class="button is-success is-fullwidth" type="submit">Create Account</button>
            </div>
            </div>

            <p id="register-error" class="has-text-danger has-text-centered mt-3"></p>

            <p class="has-text-dark has-text-centered mt-4">
            Already have an account?
            <a href="#login" id="register_here" >Log in</a>
            </p>
        </form>
        </div>
    </div>
    </section>
`;
};

const setupRegister = () => {
const form = document.getElementById('register-form');
const errorText = document.getElementById('register-error');

if (form) {
    form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    try {
        const existingUsers = await getUsers();

        const usernameTaken = existingUsers.some(u => u.username === username);
        const emailTaken = existingUsers.some(u => u.email === email);

        if (usernameTaken) {
        errorText.textContent = 'Username is already taken.';
        return;
        }

        if (emailTaken) {
        errorText.textContent = 'Email is already registered.';
        return;
        }

        const newUser = {
        username,
        email,
        password,
        role: 'user'
        };

        const created = await createUser(newUser);

        localStorage.setItem('session', JSON.stringify(created));
        window.location.hash = '#home';
    } catch (err) {
        errorText.textContent = 'Server error.';
    }
    });
}
};

export default () => {
setTimeout(setupRegister, 0);
return Register();
};
