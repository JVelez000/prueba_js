import EventCards from '../components/event_cards.js';
import { getEvents, updateEvents } from '../api/api.js';
import Aside_bar from '../components/aside_bar.js';

const Events = () => {
  return `
    <div class="columns m-0" style="min-height: 100vh;">
      <div class="column is-narrow p-0" style="position: sticky; top: 0; height: 100vh;">
        ${Aside_bar()}
      </div>
      <div class="column p-0">
        <section class="section">
          <div class="container">
            <h1 id="EventsH1" class="title has-text-centered">Events</h1>
            <div id="events-container" class="mt-5"></div>
          </div>
        </section>
      </div>
    </div>
  `;
};

const setupEvents = async () => {
  const container = document.getElementById('events-container');
  const session = JSON.parse(localStorage.getItem('session'));
  const isAdmin = session?.role === 'admin';

  if (!session) {
    window.location.hash = '#login';
    return;
  }

  const fetchAndRender = async () => {
    const events = await getEvents();
    const enabledEvents = events.filter(p => p.enabled || isAdmin);
    container.innerHTML = enabledEvents.map(EventCards).join('');
  };

  await fetchAndRender();

  container.addEventListener('click', async (e) => {
    const buyBtn = e.target.closest('button[data-id]');
    const deleteBtn = e.target.closest('button[data-delete]');
    const editBtn = e.target.closest('button[data-edit]');

    // COMPRAR
    if (buyBtn) {
      const stock = parseInt(buyBtn.dataset.stock);
      const price = parseFloat(buyBtn.dataset.price);
      const name = buyBtn.dataset.name;

      if (stock === 0) {
        alert('Out of stock.');
        return;
      }

      const qty = parseInt(prompt(`How many "${name}" do you want to buy? Max: ${stock}`));
      if (!qty || qty < 1 || qty > stock) {
        alert('Invalid quantity.');
        return;
      }

      const total = qty * price;
      const confirmed = confirm(`Confirm purchase of ${qty} "${name}" for $${total.toFixed(2)}?`);
      if (!confirmed) return;

      const updated = await updateEvents(buyBtn.dataset.id, {
        stock: stock - qty
      });

      if (updated) {
        alert('Purchase successful!');
        fetchAndRender();
      } else {
        alert('Failed to purchase.');
      }
    }

    // ELIMINAR
    if (deleteBtn) {
      const id = deleteBtn.dataset.delete;
      const confirmed = confirm('Are you sure you want to delete this event?');
      if (!confirmed) return;

      const res = await fetch(`http://localhost:3000/events/${id}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        alert('Event deleted.');
        fetchAndRender();
      } else {
        alert('Error deleting event.');
      }
    }

    // EDITAR
    if (editBtn) {
      const id = editBtn.dataset.edit;
      const events = await getEvents();
      const event = events.find(ev => ev.id == id);

      const newName = prompt('New name:', event.name);
      const newStock = prompt('New stock:', event.stock);
      const newPrice = prompt('New price:', event.price);

      if (newName && newStock && newPrice) {
        await updateEvents(id, {
          name: newName,
          stock: parseInt(newStock),
          price: parseFloat(newPrice)
        });
        alert('Event updated.');
        fetchAndRender();
      }
    }
  });
};

export default () => {
  setTimeout(setupEvents, 0);
  return Events();
};