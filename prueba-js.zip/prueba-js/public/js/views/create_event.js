import Aside_bar from '../components/aside_bar.js';
import { createEvents } from '../api/api.js';

const CreateEvent = () => {
  const session = JSON.parse(localStorage.getItem('session'));

  if (!session || session.role !== 'admin') {
    window.location.hash = '#login';
    return '';
  }

  return `
    <div class="columns m-0 is-gapless">
      <div class="column is-narrow p-0">
        ${Aside_bar()}
      </div>

      <div class="column">
        <section class="section">
          <div class="container">
            <div class="box" style="max-width: 600px; margin: 0 auto; background-color: #f5f5f5; border-radius: 12px; padding: 2rem;">
              <h1 class="title has-text-centered">Create Event</h1>

              <form id="event-form">
                <div class="field">
                  <label class="label">Name</label>
                  <div class="control">
                    <input placeholder="Event name" class="input input is-link is-rounded is-focused" type="text" id="event-name" required>
                  </div>
                </div>

                <div class="field">
                  <label class="label">Description</label>
                  <div class="control">
                    <textarea placeholder="Event Description" class="textarea input is-link is-focused" id="event-description" required></textarea>
                  </div>
                </div>

                <div class="field is-flex is-justify-content-space-between">
                  <div class="control is-flex-grow-1 mr-2">
                    <label class="label">Date</label>
                    <input class="input input is-link is-rounded is-focused" type="date" id="event-date" required>
                  </div>
                  <div class="control is-flex-grow-1 ml-2">
                    <label class="label">Capacity</label>
                    <input placeholder="Event Stock" class="input input is-link is-rounded is-focused" type="number" id="event-stock" required>
                  </div>
                </div>

                <div class="field">
                  <label class="label">Price</label>
                  <div class="control">
                    <input placeholder="Event Price" class="input input is-link is-rounded is-focused" type="number" step="0.01" min="0" id="event-price" required>
                  </div>
                </div>

                <div class="field is-grouped mt-4">
                  <div class="control">
                    <button id="cancel_event" type="reset" class="button is-light">Cancel</button>
                  </div>
                  <div class="control">
                    <button type="submit" class="button" style="font-weight: 600; width: 100px; background-color: #5e17eb; color: white;">Save</button>
                  </div>
                </div>
                <p id="event-msg" class="has-text-centered mt-4"></p>
              </form>
            </div>
          </div>
        </section>
      </div>
    </div>
  `;
};

const setupCreateEvent = () => {
  const form = document.getElementById('event-form');
  const msg = document.getElementById('event-msg');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const name = document.getElementById('event-name').value.trim();
      const description = document.getElementById('event-description').value.trim();
      const date = document.getElementById('event-date').value;
      const stock = parseInt(document.getElementById('event-stock').value);
      const price = parseFloat(document.getElementById('event-price').value);

      try {
        const event = {
          name,
          description,
          date,
          stock,
          price,
          enabled: true
        };

        const res = await createEvents(event);

        if (res && res.id) {
          msg.textContent = 'Event created successfully!';
          msg.classList.remove('has-text-danger');
          msg.classList.add('has-text-success');
          form.reset();
        } else {
          msg.textContent = 'Failed to create event.';
          msg.classList.remove('has-text-success');
          msg.classList.add('has-text-danger');
        }
      } catch (err) {
        msg.textContent = 'Server error.';
        msg.classList.add('has-text-danger');
      }
    });
  }
};

export default () => {
  setTimeout(setupCreateEvent, 0);
  return CreateEvent();
};