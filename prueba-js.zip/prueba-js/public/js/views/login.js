import { getUsers } from '../api/api.js';

const Login = () => {
return `
    <section class="section">
    <div class="container is-flex is-justify-content-center">
        <div class="box" style="max-width: 400px; width: 100%; background-color:rgb(255, 255, 255); border-radius: 12px;">
        <h1 class="title has-text-centered">Login</h1>

        <form id="login-form">
            <div class="field">
            <label class="label has-text-dark">Username or Email</label>
            <div class="control">
                <input class="input" type="text" id="identifier" required>
            </div>
            </div>

            <div class="field">
            <label class="label has-text-dark">Password</label>
            <div class="control">
                <input class="input" type="password" id="password" required>
            </div>
            </div>

            <div class="field mt-4">
            <div class="control">
                <button id="LoginBtn" style=" font-weight: 600" class=" has-text-light button:hover button is-fullwidth" type="submit">Login</button>
            </div>
            </div>

            <p id="login-error" class="has-text-danger has-text-centered mt-3"></p>

            <p class="has-text-dark has-text-centered mt-4">
            Don't have an account?
            <a href="#register" id="log_here" >Register here</a>
            </p>
        </form>
        </div>
    </div>
    </section>
`;
};

const setupLogin = () => {
const form = document.getElementById('login-form');
const errorText = document.getElementById('login-error');

if (form) {
    form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const identifier = document.getElementById('identifier').value.trim();
    const password = document.getElementById('password').value.trim();

    try {
        // Get all users (no filter by password in query)
        const users = await getUsers();

        // Find user by username or email and match password
        const user = users.find(u =>
        (u.username === identifier || u.email === identifier) && u.password === password
        );

        if (user) {
        localStorage.setItem('session', JSON.stringify(user));
        window.location.hash = '#home';
        } else {
        errorText.textContent = 'Invalid credentials.';
        }
    } catch (err) {
        errorText.textContent = 'Server error.';
    }
    });
}
};

export default () => {
setTimeout(setupLogin, 0);
return Login();
};
