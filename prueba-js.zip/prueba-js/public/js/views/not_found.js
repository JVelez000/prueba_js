const NotFound = () => {
  return `<h1 class="has-text-danger">404 - Page Not Found</h1>`;
};

export default NotFound;
