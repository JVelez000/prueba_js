const EventCards = (event) => {
  const session = JSON.parse(localStorage.getItem('session'));
  const isAdmin = session?.role === 'admin';
  const disabled = event.stock === 0;

  return `
    <div class="box has-background-light has-text-light mb-4 p-4" style="border-radius: 12px;">
        <div class="has-text-centered mb-3">
            <span id="Title" class="tag has-text-weight-bold px-5 py-3" style="border-radius: 12px; font-size: 1.2rem;"> ${event.name} </span>
        </div>
      <p id="event_details"><strong id="event_details">Stock:</strong> ${event.stock}</p>
      <p id="event_details"><strong id="event_details">Price:</strong> $${event.price.toFixed(2)}</p>
      <p id="event_details"><strong id="event_details">Description:</strong> ${event.description}</p>
      <p id="event_details"><strong id="event_details">Date:</strong> ${event.date}</p>

      <div class="mt-4 buttons are-small is-flex is-justify-content-flex-end">
        ${!isAdmin && !disabled ? `
          <button 
            class="button is-success"
            style="border-radius: 8px; background-color: #23d160;"
            data-id="${event.id}" 
            data-name="${event.name}" 
            data-stock="${event.stock}" 
            data-price="${event.price}">
            ✅ Buy
          </button>` : disabled ? `
          <span disabled style="height: 27px; font-weight: 1000;" class="button tag is-danger is-light">Out of stock</span>` : ''
        }

        ${isAdmin ? `
          <button 
            class="button"
            style="border-radius: 8px; font-weight: 1000; background-color: rgb(161, 126, 255); color:rgb(255, 255, 255);"
            data-edit="${event.id}">
            ✏️ Edit
          </button>
          <button 
            class="button"
            style="border-radius: 8px; font-weight: 1000; background-color:rgb(255, 26, 72); color: white;"
            data-delete="${event.id}">
            🗑️ Delete
          </button>
        ` : ''}
      </div>
    </div>
  `;
};

export default EventCards;