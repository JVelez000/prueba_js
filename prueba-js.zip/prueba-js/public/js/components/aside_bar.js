const Aside_bar = () => {
  const session = JSON.parse(localStorage.getItem('session'));
  const currentHash = window.location.hash.toLowerCase();
  const isAuthPage = ['#login', '#register'].includes(currentHash);
  const isAdmin = session?.role === 'admin';
  const username = session?.username || 'User';
  const profilePic = session?.photo || 'https://i.pravatar.cc/100';

  return `
    ${isAuthPage ? '' : `
      <aside class="menu has-background-light p-5 has-text-centered" style="width: 250px;">
        <p style="padding-bottom: 50px;" class="title is-5 mb-3">Events</p>

        <figure style="padding-bottom: 80px;" class="image is-128x128 is-inline-block mb-3">
          <img class="is-rounded" src="${profilePic}" alt="Profile Picture">
        </figure>

        <p class="has-text-weight-bold has-text-dark">${username}</p>
        <p class="has-text-link mb-5">${isAdmin ? 'Role: 👑 Admin' : 'Role: User 🙍‍♂️'}</p>

        <div class="buttons is-centered is-flex-direction-column">
          <a href="#home" style=" background-color: rgb(112, 61, 250); color: white; font-weight: 600;" class="button is-fullwidth mb-2">
            <span class="icon">📅<i class="fas fa-calendar-alt"></i></span>
            <span>Events</span>
          </a>

          ${isAdmin ? `
          <a href="#create_event" style=" background-color: rgb(161, 126, 255); color: white; font-weight: 600;" class="button is-warning is-fullwidth mb-2">
            <span class="icon">➕<i class="fas fa-plus"></i></span>
            <span>Create</span>
          </a>
          ` : ''}

          <a href="#" style=" background-color: red; width: 203px; color: white; border-color:transparent; " id="logout-link" class="button is-full-width">
            Logout&nbsp;<i class="fas fa-sign-out-alt"></i>
          </a>
        </div>
      </aside>
    `}
  `;
};

const setupAside_bar = () => {
  const logoutLink = document.getElementById('logout-link');
  if (logoutLink) {
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      localStorage.removeItem('session');
      window.location.hash = '#login';
    });
  }
};

export default () => {
  setTimeout(setupAside_bar, 0);
  return Aside_bar();
};