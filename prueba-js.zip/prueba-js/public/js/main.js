import router from './router.js';
import Aside_bar from './components/aside_bar.js';

const root = document.getElementById('app');

const render = () => {
root.innerHTML = `
    <div class="mt-5">
    ${router()}
    </div>
`;
};

window.addEventListener('hashchange', render);
window.addEventListener('load', render);
