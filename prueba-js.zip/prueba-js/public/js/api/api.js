const API_URL = 'http://localhost:3000';

export const getUsers = async (query = '') => {
const res = await fetch(`${API_URL}/users${query}`);
return await res.json();
};

export const createUser = async (user) => {
const res = await fetch(`${API_URL}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(user)
});
return await res.json();
};

export const getEvents = async () => {
const res = await fetch(`${API_URL}/events`);
return await res.json();
};

export const createEvents = async (event) => {
const res = await fetch(`${API_URL}/events`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(event)
});
return await res.json();
};

export const updateEvents = async (id, updates) => {
  const res = await fetch(`${API_URL}/events/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  return await res.json();
};