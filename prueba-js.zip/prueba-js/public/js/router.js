import Login from './views/login.js';
import Register from './views/register.js';
import NotFound from './views/not_found.js';
import CreateEvent from './views/create_event.js'
import Events from './views/events.js'

const routes = {
  '#login': Login,
  '#register': Register,
  '#create_event' : CreateEvent,
  '#home' : Events
};

const isAuthenticated = () => {
  return !!localStorage.getItem('session');
};

const isAdmin = () => {
  const session = JSON.parse(localStorage.getItem('session'));
  return session?.role === 'admin';
};

const router = () => {
  const hash = window.location.hash.toLowerCase() || '#home';

  const publicRoutes = ['#login', '#register'];
  const protectedRoutes = ['#home', '#create_event'];

  if (protectedRoutes.includes(hash) && !isAuthenticated()) {
    window.location.hash = '#login';
    return '';
  }

  if (publicRoutes.includes(hash) && isAuthenticated()) {
    window.location.hash = '#home';
    return '';
  }

  if (hash === '#admin' && !isAdmin()) {
    return NotFound();
  }

  const view = routes[hash];
  return view ? view() : NotFound();
};

export default router;
